## written by Moreno I. Coco (moreno.cocoi@gmail.com)

## aggregate a measure alone or against another one, and calculate
## prop, freq, ci, se fi.

## interval = a range (min, max) of the measure we are aggregating
## unit = the unit of aggregation
## measure = the dep. measure to be aggregated
## o.measure = the other measure 

binmeasure <- function (interval, unit, measure, o.measure,
                        number){
  
  bins = seq(interval[1],interval[2],unit)
  Freq = Mu = CI = Prop = SE_Prop = SE_Mu = vector(); 
  
  if (number == 1){
    for (i in 1:(length(bins)-1)){
      proportion = vector(length = length(measure),
        mode = "numeric")

      if (i + 1 != length(bins) ){
        ## make sure to include the last bin
        a = which(bins[i] <= measure & measure < bins[i+1])
      } else {
        a = which(bins[i] <= measure & measure <= bins[i+1])
      }

      proportion[a] = 1
      
      freq = length(measure[a])
      mu_prop = mean(proportion)
      se_prop = sqrt(var(proportion, na.rm = TRUE)/length(proportion))
              
      mU= mean(measure[a]); Sd = sd(measure[a]);
      se_mu = sqrt(var(measure[a], na.rm = TRUE)/length(measure[a]))
      
      if (is.na(Sd) == TRUE | Sd==0){
        ciVS <- c(0,0)
      } else {
        ciVS<- t.test(measure[a], mu=mU, conf.level=0.95)$conf.int[1:2]}
      Freq = c(Freq, freq)
      Mu   = c(Mu,mU);
      Prop = c(Prop, mu_prop)
      SE_Prop = c(SE_Prop, se_prop)
      SE_Mu = c(SE_Mu, se_mu)
      CI   = rbind(CI,ciVS, deparse.level=0);
    }
  }
  
  if (number == 2){
    i = 1
    for (i in 1:( length( bins ) -1 ) ){
      
      proportion = vector(length = length(measure), mode = "numeric")
      if (i + 1 != length(bins) ){
        ## make sure to include the last bin
        a = which(bins[i] <= measure & measure < bins[i+1])
      } else {
        a = which(bins[i] <= measure & measure <= bins[i+1])
      }
      
      proportion[a] = 1
      
      freq = length(measure[a])
      mu_prop = mean(proportion)
      se_prop = sqrt(var(proportion, na.rm = TRUE)/length(proportion))
      
      mU= mean(o.measure[a]); Sd = sd(o.measure[a]);
      se_mu = sqrt(var(o.measure[a],
        na.rm = TRUE)/length(o.measure[a]))
      
      if ( is.na(Sd) == TRUE | Sd == 0){
        ciVS<-c(0,0)
      } else {
        ciVS = t.test(o.measure[a], mu=mU, conf.level=0.95)$conf.int[1:2]}
      
      Freq = c(Freq, freq)
      Mu   = c(Mu,mU);
      Prop = c(Prop,mu_prop)
      SE_Prop = c(SE_Prop, se_prop)
      SE_Mu = c(SE_Mu, se_mu)
      CI   = rbind(CI,ciVS, deparse.level=0);
    }
  }
        
  return (list(proportion = Prop, frequency = Freq,
               mu = Mu, ci = CI, seprop = SE_Prop,
               semu = SE_Mu))
  
}
