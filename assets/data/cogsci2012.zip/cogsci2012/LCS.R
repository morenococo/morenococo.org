## written by Moreno I. Coco

LCS <- function(sq1,sq2){

m = length(sq1); n = length(sq2);

if (m ==1 | n==1){

    common = intersect(sq1,sq2)

    if (length(common) == 1){
        Sim = 1/sqrt(m*n)
        aLongestString = common }
    
    if (length(common) == 0 ){
        Sim = 0
        aLongestString = vector()
    }
    
} else {

    b = matrix(0,nrow=m+1, ncol=n+1)
    b[,1] = 1;#Up
    b[1,] = 2;#Left


    L=matrix(0,nrow=m+1,ncol=n+1)

    for (i in 1:m+1){
        for (j in 1:n+1){
            
            if (sq1[i-1] == sq2[j-1]){
                L[i,j] = L[i-1,j-1] + 1;
                b[i,j] = 3; #Up and left
            } else {
                L[i,j] = L[i-1,j-1];}
            
            if (L[i-1,j] >= L[i,j]){
                L[i,j] = L[i-1,j];
                b[i,j] = 1; #Up
            }
            
            if(L[i,j-1] >= L[i,j]){
                L[i,j] = L[i,j-1];
                b[i,j] = 2; #Left
        }
        }
    }
    

    L = L[2:nrow(L),];
    L = L[,2:ncol(L)];
    b = b[2:nrow(b),];
    b = b[,2:ncol(b)];
    
    dist = L[m,n];
    
    Sim = dist/sqrt(m*n)

    if(dist == 0){
        aLongestString = indxString = vector()
    } else {## now backtrack to find the longest subsequence
        i = m;
        j = n;
        p = dist;
        aLongestString = indxString = vector();
        while(i>0 && j>0){
            if(b[i,j] == 3){
                indxString[p] = i;
                aLongestString[p] = sq1[i];
                p = p-1;
                i = i-1;
                j = j-1;
            } else if (b[i,j] == 1){
                i = i-1;
        }  else if (b[i,j] == 2){
            j = j-1
        }
            
        }

        if (is.character(aLongestString[1])){
            aLongestString = as.character(aLongestString);
        } else {
            aLongestString = as.matrix(aLongestString);}
    }
    
}

return (list(similarity = Sim, lcs = aLongestString, ixlcs = indxString))

}


